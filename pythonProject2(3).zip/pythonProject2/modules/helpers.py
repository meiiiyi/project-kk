import toml

def load_config(config_path):
    return toml.load(config_path)





