import numpy as np

def geo_paths(S, T, r, sigma, steps, N):
    """
    Generate geometric Brownian motion paths for stock prices.

    Inputs:
    S = Current stock price
    T = Time to maturity (1 year = 1, 1 month = 1/12)
    r = Risk-free interest rate
    sigma = Volatility
    steps = Number of time steps
    N = Number of trials

    Output:
    [steps, N] Matrix of asset paths
    """
    dt = T / steps
    ST = np.log(S) + np.cumsum(((r - sigma ** 2 / 2) * dt + sigma * np.sqrt(dt) * np.random.normal(size=(steps, N))), axis=0)
    return np.exp(ST)

def monte_carlo_simulation(S, K, T, r, sigma, steps, N, option_type='Call'):
    """
    Monte Carlo simulation for European option pricing.

    Inputs:
    S = Current stock price
    K = Strike price
    T = Time to maturity
    r = Risk-free interest rate
    sigma = Volatility
    steps = Number of time steps
    N = Number of trials
    option_type = 'Call' or 'Put'

    Output:
    Monte Carlo simulated price
    """
    paths = geo_paths(S, T, r, sigma, steps, N)
    if option_type == 'Call':
        payoffs = np.maximum(paths[-1] - K, 0)
    else:
        payoffs = np.maximum(K - paths[-1], 0)
    option_price = np.exp(-r * T) * np.mean(payoffs)
    return option_price




